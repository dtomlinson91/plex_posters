.. toctree::
   :maxdepth: 1
   :caption: Overview
   :titlesonly:

   introduction
   configuration

.. toctree::
   :maxdepth: 1
   :caption: Modules
   :titlesonly:

   plex_posters
   plex_posters.config
   plex_posters.lib
